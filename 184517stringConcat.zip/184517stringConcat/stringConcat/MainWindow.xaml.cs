﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace stringConcat
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnConcat_Click(object sender, RoutedEventArgs e)
        {
            string fName, lName;
            string fullName;
            int yearBorn;

            fName = txtFirstName.Text;
            fName = fName.Trim();
            lName = txtLastName.Text;
            lName = lName.Trim();
            yearBorn = calBDay.SelectedDate.Value.Year;

            //Concatenation
         
            fullName = fName + " " + lName;
            if (fullName == "Jordan Ross") 
            {
                if(yearBorn >=2000)
                {
                    lblOutput.Content = "sup my dude, want to go hit my juul";
                }
                else
                {
                    lblOutput.Content = "Bro you old";
                }
                //do this if true
                lblOutput.Content = "sup my dude, want to go hit my juul";
            }
            else
            {
                lblOutput.Content = fullName;
            }
        }
    }
}
